package hackathon.bean;

import java.util.Date;

public class MasterDataVO {
	private int custId;
	private String custName;
	private double amount;
	private Date txnDate;
	public MasterDataVO(int custId, String custName, double amount, Date txnDate) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.amount = amount;
		this.txnDate = txnDate;
	}
	@Override
	public String toString() {
		return "MasterDataVO [custId=" + custId + ", custName=" + custName
				+ ", amount=" + amount + ", txnDate=" + txnDate + "]";
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Date getTxnDate() {
		return txnDate;
	}
	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}
}
