package hackathaon.fileCreator;

import hackathon.bean.MasterDataVO;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class CsvWriter {
	private static final String FILE_HEADER = "CustomerId,CustomerName,Amount,TransactionDate";
	private static final String COMMA_DELIMITER = ",";
	private static final String NEW_LINE_SEPARATOR = "\n";
	private static int limit = 500;
	public static void main(String[] args){
		String outFile = "TRANSACTIONSUMMERY.csv";
		String dstn = "D:/hackOut/";
		File csvOutFile = new File(dstn+outFile);
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(csvOutFile);
			fileWriter.append(FILE_HEADER.toString());
			fileWriter.append(NEW_LINE_SEPARATOR);
			
			List<MasterDataVO> masterDataVOList = new ArrayList<MasterDataVO>();
			MasterDataVO masterDataVO = new MasterDataVO(0, "fgsdfj", 21, new Date());
			masterDataVOList.add(masterDataVO);
			masterDataVOList = randomMasterDataPopulation(masterDataVOList);
			for (MasterDataVO masterData : masterDataVOList) {
				fileWriter.append(String.valueOf(masterData.getCustId()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(masterData.getCustName());
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(masterData.getAmount()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(masterData.getTxnDate()));
				fileWriter.append(NEW_LINE_SEPARATOR);
			}
		}catch(Exception e){
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}finally {
			
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
                e.printStackTrace();
			}
			
		}
	}
	
	public static List<MasterDataVO> randomMasterDataPopulation(List<MasterDataVO> masterDataVOList){
		
		for(int i=0; i < limit ; i++ ){
			MasterDataVO masterDataVO = new MasterDataVO(getRandomNumberFrom(100,200), "abc", getRandomNumberFrom(50000,10000000), new Date());
			masterDataVOList.add(masterDataVO);
		}
		
		return masterDataVOList;
	}
	
	public static int getRandomNumberFrom(int min, int max) {
        Random foo = new Random();
        int randomNumber = foo.nextInt((max + 1) - min) + min;

        return randomNumber;

    }
}
